<?php
function gavias_blockbuilder_override_shortcodes(){
   return array('gsc_quote', 'gsc_quote_text', 'gsc_gmap', 'gsc_button', 'gsc_coming_soon', 'gsc_view');
}
