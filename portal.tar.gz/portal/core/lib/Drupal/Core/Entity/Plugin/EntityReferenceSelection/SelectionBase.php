<?php

namespace Drupal\Core\Entity\Plugin\EntityReferenceSelection;

/**
 * @deprecated in Drupal 8.0.0, will be removed before Drupal 9.0.0.
 *   Use \Drupal\Core\Entity\Plugin\EntityReferenceSelection\DefaultSelection
 */
class SelectionBase extends DefaultSelection { }
