<?php

/* themes/gavias_aquarius/templates/page/footer.html.twig */
class __TwigTemplate_f838e5ab1b6e4288e89f77ab75ab24044f768365143edb1de31104fc9745411a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 3);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('if'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<footer id=\"footer\" class=\"footer\">
  
  ";
        // line 3
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "before_footer", array())) {
            // line 4
            echo "   <div class=\"footer-top\">
      <div class=\"container\">
        <div class=\"row\">
          <div class=\"col-xs-12\">
            <div class=\"before_footer area\">
                ";
            // line 9
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "before_footer", array()), "html", null, true));
            echo "
            </div>
          </div>
        </div>     
      </div>   
    </div> 
   ";
        }
        // line 16
        echo "   
   <div class=\"footer-center\">
      <div class=\"container\">      
         <div class=\"row\">
              
              ";
        // line 21
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_first", array())) {
            // line 22
            echo "                <div class=\"footer-first col-lg-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_first_size"]) ? $context["footer_first_size"] : null), "html", null, true));
            echo " col-md-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_first_size"]) ? $context["footer_first_size"] : null), "html", null, true));
            echo " col-sm-12 col-xs-12 column\">
                  ";
            // line 23
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_first", array()), "html", null, true));
            echo "
                </div> 
              ";
        }
        // line 26
        echo "
              ";
        // line 27
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_second", array())) {
            // line 28
            echo "               <div class=\"footer-second col-lg-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_second_size"]) ? $context["footer_second_size"] : null), "html", null, true));
            echo " col-md-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_second_size"]) ? $context["footer_second_size"] : null), "html", null, true));
            echo " col-sm-12 col-xs-12 column\">
                  ";
            // line 29
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_second", array()), "html", null, true));
            echo "
                </div> 
              ";
        }
        // line 32
        echo "
              ";
        // line 33
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_third", array())) {
            // line 34
            echo "                <div class=\"footer-third col-lg-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_third_size"]) ? $context["footer_third_size"] : null), "html", null, true));
            echo " col-md-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_third_size"]) ? $context["footer_third_size"] : null), "html", null, true));
            echo " col-sm-12 col-xs-12 column\">
                  ";
            // line 35
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_third", array()), "html", null, true));
            echo "
                </div> 
              ";
        }
        // line 38
        echo "
              ";
        // line 39
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_four", array())) {
            // line 40
            echo "                 <div class=\"footer-four col-lg-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_four_size"]) ? $context["footer_four_size"] : null), "html", null, true));
            echo " col-md-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["footer_four_size"]) ? $context["footer_four_size"] : null), "html", null, true));
            echo " col-sm-12 col-xs-12 column\">
                  ";
            // line 41
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_four", array()), "html", null, true));
            echo "
                </div> 
              ";
        }
        // line 44
        echo "         </div>   
      </div>
   </div>   

   ";
        // line 48
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "copyright", array())) {
            // line 49
            echo "   <div class=\"copyright\">
      <div class=\"container\">
        <div class=\"copyright-inner\">
            ";
            // line 52
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "copyright", array()), "html", null, true));
            echo "
        </div>   
      </div>   
   </div>
 ";
        }
        // line 57
        echo "
</footer>

";
    }

    public function getTemplateName()
    {
        return "themes/gavias_aquarius/templates/page/footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 57,  155 => 52,  150 => 49,  148 => 48,  142 => 44,  136 => 41,  129 => 40,  127 => 39,  124 => 38,  118 => 35,  111 => 34,  109 => 33,  106 => 32,  100 => 29,  93 => 28,  91 => 27,  88 => 26,  82 => 23,  75 => 22,  73 => 21,  66 => 16,  56 => 9,  49 => 4,  47 => 3,  43 => 1,);
    }
}
/* <footer id="footer" class="footer">*/
/*   */
/*   {% if page.before_footer %}*/
/*    <div class="footer-top">*/
/*       <div class="container">*/
/*         <div class="row">*/
/*           <div class="col-xs-12">*/
/*             <div class="before_footer area">*/
/*                 {{ page.before_footer }}*/
/*             </div>*/
/*           </div>*/
/*         </div>     */
/*       </div>   */
/*     </div> */
/*    {% endif %}*/
/*    */
/*    <div class="footer-center">*/
/*       <div class="container">      */
/*          <div class="row">*/
/*               */
/*               {% if page.footer_first %}*/
/*                 <div class="footer-first col-lg-{{ footer_first_size }} col-md-{{ footer_first_size }} col-sm-12 col-xs-12 column">*/
/*                   {{ page.footer_first }}*/
/*                 </div> */
/*               {% endif %}*/
/* */
/*               {% if page.footer_second %}*/
/*                <div class="footer-second col-lg-{{ footer_second_size }} col-md-{{ footer_second_size }} col-sm-12 col-xs-12 column">*/
/*                   {{ page.footer_second }}*/
/*                 </div> */
/*               {% endif %}*/
/* */
/*               {% if page.footer_third %}*/
/*                 <div class="footer-third col-lg-{{ footer_third_size }} col-md-{{ footer_third_size }} col-sm-12 col-xs-12 column">*/
/*                   {{ page.footer_third }}*/
/*                 </div> */
/*               {% endif %}*/
/* */
/*               {% if page.footer_four %}*/
/*                  <div class="footer-four col-lg-{{ footer_four_size }} col-md-{{ footer_four_size }} col-sm-12 col-xs-12 column">*/
/*                   {{ page.footer_four }}*/
/*                 </div> */
/*               {% endif %}*/
/*          </div>   */
/*       </div>*/
/*    </div>   */
/* */
/*    {% if page.copyright %}*/
/*    <div class="copyright">*/
/*       <div class="container">*/
/*         <div class="copyright-inner">*/
/*             {{ page.copyright }}*/
/*         </div>   */
/*       </div>   */
/*    </div>*/
/*  {% endif %}*/
/* */
/* </footer>*/
/* */
/* */
