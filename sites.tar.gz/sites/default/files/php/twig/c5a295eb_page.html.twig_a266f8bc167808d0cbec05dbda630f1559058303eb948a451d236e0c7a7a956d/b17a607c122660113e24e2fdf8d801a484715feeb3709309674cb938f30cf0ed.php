<?php

/* themes/gavias_aquarius/templates/page/page.html.twig */
class __TwigTemplate_7e94115ac39e1b0a9715c90b1055c8eeb048e679290614a04c5e33018de79b63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 8, "if" => 11);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('include', 'if'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 7
        echo "<div class=\"body-page\">
\t";
        // line 8
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/templates/page/parts/preloader.html.twig"), "themes/gavias_aquarius/templates/page/page.html.twig", 8)->display($context);
        // line 9
        echo "   ";
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/templates/page/header.html.twig"), "themes/gavias_aquarius/templates/page/page.html.twig", 9)->display($context);
        // line 10
        echo "\t
   ";
        // line 11
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "breadcrumbs", array())) {
            // line 12
            echo "\t\t<div class=\"breadcrumbs\">
\t\t\t";
            // line 13
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "breadcrumbs", array()), "html", null, true));
            echo "
\t\t</div>
\t";
        }
        // line 16
        echo "\t
\t<div role=\"main\" class=\"main main-page\">
\t
\t\t<div class=\"clearfix\"></div>
\t\t";
        // line 20
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "slideshow_content", array())) {
            // line 21
            echo "\t\t\t<div class=\"slideshow_content area\">
\t\t\t\t";
            // line 22
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "slideshow_content", array()), "html", null, true));
            echo "
\t\t\t</div>
\t\t";
        }
        // line 24
        echo "\t

\t\t";
        // line 26
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array())) {
            // line 27
            echo "\t\t\t<div class=\"help\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"content-inner\">
\t\t\t\t\t\t";
            // line 30
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array()), "html", null, true));
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t";
        }
        // line 35
        echo "
\t\t";
        // line 36
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "fw_before_content", array())) {
            // line 37
            echo "\t\t\t<div class=\"fw-before-content area\">
\t\t\t\t";
            // line 38
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "fw_before_content", array()), "html", null, true));
            echo "
\t\t\t</div>
\t\t";
        }
        // line 41
        echo "\t\t
\t\t<div class=\"clearfix\"></div>
\t\t";
        // line 43
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "before_content", array())) {
            // line 44
            echo "\t\t\t<div class=\"before_content area\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-xs-12\">
\t\t\t\t\t\t\t";
            // line 48
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "before_content", array()), "html", null, true));
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t";
        }
        // line 54
        echo "\t\t
\t\t<div class=\"clearfix\"></div>
\t\t
\t\t<div id=\"content\" class=\"content content-full\">
\t\t\t<div class=\"container\">
\t\t\t\t";
        // line 59
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/templates/page/main.html.twig"), "themes/gavias_aquarius/templates/page/page.html.twig", 59)->display($context);
        // line 60
        echo "\t\t\t</div>
\t\t</div>

\t\t";
        // line 63
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "highlighted", array())) {
            // line 64
            echo "\t\t\t<div class=\"highlighted area\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t";
            // line 66
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "highlighted", array()), "html", null, true));
            echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t";
        }
        // line 70
        echo "
\t\t";
        // line 71
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "after_content", array())) {
            // line 72
            echo "\t\t\t<div class=\"area after_content\">
\t\t\t\t<div class=\"container-fw\">
\t          \t<div class=\"content-inner\">
\t\t\t\t\t\t ";
            // line 75
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "after_content", array()), "html", null, true));
            echo "
\t          \t</div>
        \t\t</div>
\t\t\t</div>
\t\t";
        }
        // line 80
        echo "\t\t
\t\t";
        // line 81
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "fw_after_content", array())) {
            // line 82
            echo "\t\t\t<div class=\"fw-before-content area\">
\t\t\t\t";
            // line 83
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "fw_after_content", array()), "html", null, true));
            echo "
\t\t\t</div>
\t\t";
        }
        // line 86
        echo "
\t</div>

\t";
        // line 89
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/templates/page/footer.html.twig"), "themes/gavias_aquarius/templates/page/page.html.twig", 89)->display($context);
        // line 90
        echo "\t";
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/templates/page/parts/offcanvas.html.twig"), "themes/gavias_aquarius/templates/page/page.html.twig", 90)->display($context);
        // line 91
        echo "</div>

";
    }

    public function getTemplateName()
    {
        return "themes/gavias_aquarius/templates/page/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 91,  202 => 90,  200 => 89,  195 => 86,  189 => 83,  186 => 82,  184 => 81,  181 => 80,  173 => 75,  168 => 72,  166 => 71,  163 => 70,  156 => 66,  152 => 64,  150 => 63,  145 => 60,  143 => 59,  136 => 54,  127 => 48,  121 => 44,  119 => 43,  115 => 41,  109 => 38,  106 => 37,  104 => 36,  101 => 35,  93 => 30,  88 => 27,  86 => 26,  82 => 24,  76 => 22,  73 => 21,  71 => 20,  65 => 16,  59 => 13,  56 => 12,  54 => 11,  51 => 10,  48 => 9,  46 => 8,  43 => 7,);
    }
}
/* {#*/
/* /***/
/*  * @file*/
/*  * Gavias's theme implementation to display a single Drupal page.*/
/*  *//* */
/* #}*/
/* <div class="body-page">*/
/* 	{% include directory ~ '/templates/page/parts/preloader.html.twig' %}*/
/*    {% include directory ~ '/templates/page/header.html.twig' %}*/
/* 	*/
/*    {% if page.breadcrumbs %}*/
/* 		<div class="breadcrumbs">*/
/* 			{{ page.breadcrumbs }}*/
/* 		</div>*/
/* 	{% endif %}*/
/* 	*/
/* 	<div role="main" class="main main-page">*/
/* 	*/
/* 		<div class="clearfix"></div>*/
/* 		{% if page.slideshow_content %}*/
/* 			<div class="slideshow_content area">*/
/* 				{{ page.slideshow_content }}*/
/* 			</div>*/
/* 		{% endif %}	*/
/* */
/* 		{% if page.help %}*/
/* 			<div class="help">*/
/* 				<div class="container">*/
/* 					<div class="content-inner">*/
/* 						{{ page.help }}*/
/* 					</div>*/
/* 				</div>*/
/* 			</div>*/
/* 		{% endif %}*/
/* */
/* 		{% if page.fw_before_content %}*/
/* 			<div class="fw-before-content area">*/
/* 				{{ page.fw_before_content }}*/
/* 			</div>*/
/* 		{% endif %}*/
/* 		*/
/* 		<div class="clearfix"></div>*/
/* 		{% if page.before_content %}*/
/* 			<div class="before_content area">*/
/* 				<div class="container">*/
/* 					<div class="row">*/
/* 						<div class="col-xs-12">*/
/* 							{{ page.before_content }}*/
/* 							</div>*/
/* 					</div>*/
/* 				</div>*/
/* 			</div>*/
/* 		{% endif %}*/
/* 		*/
/* 		<div class="clearfix"></div>*/
/* 		*/
/* 		<div id="content" class="content content-full">*/
/* 			<div class="container">*/
/* 				{% include directory ~ '/templates/page/main.html.twig' %}*/
/* 			</div>*/
/* 		</div>*/
/* */
/* 		{% if page.highlighted %}*/
/* 			<div class="highlighted area">*/
/* 				<div class="container">*/
/* 					{{ page.highlighted }}*/
/* 				</div>*/
/* 			</div>*/
/* 		{% endif %}*/
/* */
/* 		{% if page.after_content %}*/
/* 			<div class="area after_content">*/
/* 				<div class="container-fw">*/
/* 	          	<div class="content-inner">*/
/* 						 {{ page.after_content }}*/
/* 	          	</div>*/
/*         		</div>*/
/* 			</div>*/
/* 		{% endif %}*/
/* 		*/
/* 		{% if page.fw_after_content %}*/
/* 			<div class="fw-before-content area">*/
/* 				{{ page.fw_after_content }}*/
/* 			</div>*/
/* 		{% endif %}*/
/* */
/* 	</div>*/
/* */
/* 	{% include directory ~ '/templates/page/footer.html.twig' %}*/
/* 	{% include directory ~ '/templates/page/parts/offcanvas.html.twig' %}*/
/* </div>*/
/* */
/* */
