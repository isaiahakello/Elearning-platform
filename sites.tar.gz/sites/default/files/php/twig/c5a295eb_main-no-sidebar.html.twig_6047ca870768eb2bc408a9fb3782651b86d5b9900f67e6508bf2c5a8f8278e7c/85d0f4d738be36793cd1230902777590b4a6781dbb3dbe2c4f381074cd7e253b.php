<?php

/* themes/gavias_aquarius/templates/page/main-no-sidebar.html.twig */
class __TwigTemplate_ecb5181ed335555c3859aeab8b4c1286269fa34308de1e7e36cc85e3123b080f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 7);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('if'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<div class=\"content-main-inner\">

\t<div id=\"page-main-content\" class=\"main-content\">

\t\t<div class=\"main-content-inner\">
\t\t\t
\t\t\t";
        // line 7
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content_top", array())) {
            // line 8
            echo "\t\t\t\t<div class=\"content-top\">
\t\t\t\t\t";
            // line 9
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content_top", array()), "html", null, true));
            echo "
\t\t\t\t</div>
\t\t\t";
        }
        // line 12
        echo "
\t\t\t";
        // line 13
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content", array())) {
            // line 14
            echo "\t\t\t\t<div class=\"content-main\">
\t\t\t\t\t";
            // line 15
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content", array()), "html", null, true));
            echo "
\t\t\t\t</div>
\t\t\t";
        }
        // line 18
        echo "
\t\t\t";
        // line 19
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content_bottom", array())) {
            // line 20
            echo "\t\t\t\t<div class=\"content-bottom\">
\t\t\t\t\t";
            // line 21
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content_bottom", array()), "html", null, true));
            echo "
\t\t\t\t</div>
\t\t\t";
        }
        // line 24
        echo "\t\t</div>

\t</div>

</div>

";
    }

    public function getTemplateName()
    {
        return "themes/gavias_aquarius/templates/page/main-no-sidebar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 24,  84 => 21,  81 => 20,  79 => 19,  76 => 18,  70 => 15,  67 => 14,  65 => 13,  62 => 12,  56 => 9,  53 => 8,  51 => 7,  43 => 1,);
    }
}
/* <div class="content-main-inner">*/
/* */
/* 	<div id="page-main-content" class="main-content">*/
/* */
/* 		<div class="main-content-inner">*/
/* 			*/
/* 			{% if page.content_top %}*/
/* 				<div class="content-top">*/
/* 					{{ page.content_top }}*/
/* 				</div>*/
/* 			{% endif %}*/
/* */
/* 			{% if page.content %}*/
/* 				<div class="content-main">*/
/* 					{{ page.content }}*/
/* 				</div>*/
/* 			{% endif %}*/
/* */
/* 			{% if page.content_bottom %}*/
/* 				<div class="content-bottom">*/
/* 					{{ page.content_bottom }}*/
/* 				</div>*/
/* 			{% endif %}*/
/* 		</div>*/
/* */
/* 	</div>*/
/* */
/* </div>*/
/* */
/* */
